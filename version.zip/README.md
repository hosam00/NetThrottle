# Network Speed Controller

A GUI application built with Python tkinter to control download and upload speeds on Linux systems using traffic control (tc).

## Features

- **Intuitive GUI**: Easy-to-use interface for setting speed limits
- **Download Speed Control**: Limit incoming network traffic
- **Upload Speed Control**: Limit outgoing network traffic  
- **Real-time Monitoring**: Monitor current network speeds
- **Multiple Interfaces**: Support for different network interfaces (WiFi, Ethernet)
- **Flexible Units**: Set limits in Kbps or Mbps
- **Status Logging**: View current traffic control rules and network statistics

## Requirements

- Linux operating system
- Python 3.12 or higher
- Root/sudo privileges (required for traffic control)
- iproute2 package (usually pre-installed)

## Installation

### Quick Setup
```bash
# Make setup script executable
chmod +x setup.sh

# Run setup script
./setup.sh
```

### Manual Installation
```bash
# Install Python dependencies
pip install -r requirements.txt

# Install traffic control utilities (if not already installed)
sudo apt-get install iproute2  # Ubuntu/Debian
# or
sudo yum install iproute       # CentOS/RHEL
# or
sudo pacman -S iproute2        # Arch Linux

# Load ifb module for upload limiting
sudo modprobe ifb
```

## Usage

### Running the Application
```bash
# Run with sudo for full functionality
sudo python main.py

# Or run without sudo (limited functionality)
python main.py
```

### Setting Speed Limits

1. **Select Network Interface**: Choose your active network interface (e.g., wlan0 for WiFi, eth0 for Ethernet)

2. **Set Download Limit**:
   - Enter desired speed value
   - Select unit (kbps or mbps)
   - Click "Set Download Limit"

3. **Set Upload Limit**:
   - Enter desired speed value
   - Select unit (kbps or mbps)
   - Click "Set Upload Limit"

4. **Remove Limits**: Click "Remove All Limits" to clear all restrictions

### Example Speed Limits
- **1 Mbps** = Good for basic browsing
- **5 Mbps** = Suitable for streaming SD video
- **25 Mbps** = Suitable for streaming HD video
- **100 Mbps** = High-speed browsing and downloads

## How It Works

This application uses Linux's Traffic Control (tc) system to manage network bandwidth:

- **Download Limiting**: Uses HTB (Hierarchical Token Bucket) queueing discipline
- **Upload Limiting**: Uses IFB (Intermediate Functional Block) devices to redirect and limit traffic
- **Real-time Monitoring**: Uses psutil library to monitor network interface statistics

## Technical Details

### Traffic Control Commands Used
The application executes these types of commands:

```bash
# Download limiting
sudo tc qdisc add dev wlan0 root handle 1: htb default 30
sudo tc class add dev wlan0 parent 1: classid 1:1 htb rate 1000kbit
sudo tc class add dev wlan0 parent 1:1 classid 1:10 htb rate 1000kbit ceil 1000kbit

# Upload limiting (more complex)
sudo tc qdisc add dev wlan0 ingress
sudo tc filter add dev wlan0 parent ffff: protocol ip u32 match u32 0 0 flowid 1:1 action mirred egress redirect dev ifb0
```

### Network Interfaces
The application automatically detects available network interfaces and filters out:
- Loopback interfaces (lo)
- Inactive interfaces
- Virtual interfaces without IP addresses

## Troubleshooting

### Permission Issues
```bash
# If you get permission errors, run with sudo
sudo python main.py
```

### Interface Not Found
```bash
# List available interfaces
ip link show

# or
ifconfig
```

### Traffic Control Not Working
```bash
# Check if tc is installed
which tc

# Install if missing
sudo apt-get install iproute2
```

### IFB Module Issues
```bash
# Load ifb module manually
sudo modprobe ifb

# Check if loaded
lsmod | grep ifb
```

## Limitations

- **Linux Only**: This application only works on Linux systems
- **Root Required**: Requires sudo/root privileges to modify network settings
- **Interface Specific**: Speed limits apply per network interface
- **System Wide**: Affects all applications using the selected interface

## Safety Notes

- Speed limits persist until removed or system restart
- Always test with conservative limits first
- Remove limits before troubleshooting network issues
- Keep terminal access available in case GUI becomes unresponsive

## File Structure

```
speed_limiter/
├── main.py                    # Main application
├── requirements.txt           # Python dependencies
├── setup.sh                  # Setup script
├── pyproject.toml            # Project configuration
├── README.md                 # This file
└── speed_limiter_settings.json  # Settings (created on first run)
```

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is open source. Use at your own risk.

## Disclaimer

This tool modifies system network settings. Use responsibly and ensure you understand the implications of bandwidth limiting on your system.
